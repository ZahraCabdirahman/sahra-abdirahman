﻿namespace Zahra_Abdiraxmaan_Ahmed
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            groupBox1 = new GroupBox();
            Kawadabax = new Button();
            Dir = new Button();
            Tirtir = new Button();
            Extra = new CheckBox();
            Courses = new ListBox();
            Result = new Label();
            groupBox2 = new GroupBox();
            Nin = new RadioButton();
            Sage = new TextBox();
            Sid = new TextBox();
            Sname = new TextBox();
            ST_Sanadka = new Label();
            ID = new Label();
            magaca = new Label();
            Dumar = new RadioButton();
            groupBox1.SuspendLayout();
            groupBox2.SuspendLayout();
            SuspendLayout();
            // 
            // groupBox1
            // 
            groupBox1.BackColor = Color.Fuchsia;
            groupBox1.Controls.Add(Kawadabax);
            groupBox1.Controls.Add(Dir);
            groupBox1.Controls.Add(Tirtir);
            groupBox1.Controls.Add(Extra);
            groupBox1.Controls.Add(Courses);
            groupBox1.Controls.Add(Result);
            groupBox1.Controls.Add(groupBox2);
            groupBox1.Location = new Point(181, 121);
            groupBox1.Name = "groupBox1";
            groupBox1.Size = new Size(431, 663);
            groupBox1.TabIndex = 0;
            groupBox1.TabStop = false;
            groupBox1.Text = "Student Management";
            // 
            // Kawadabax
            // 
            Kawadabax.BackColor = Color.FromArgb(255, 192, 255);
            Kawadabax.Location = new Point(268, 449);
            Kawadabax.Name = "Kawadabax";
            Kawadabax.Size = new Size(112, 34);
            Kawadabax.TabIndex = 4;
            Kawadabax.Text = "&Exit:";
            Kawadabax.UseVisualStyleBackColor = false;
            Kawadabax.Click += Kawadabax_Click;
            // 
            // Dir
            // 
            Dir.BackColor = Color.FromArgb(255, 192, 255);
            Dir.Location = new Point(28, 449);
            Dir.Name = "Dir";
            Dir.Size = new Size(112, 34);
            Dir.TabIndex = 4;
            Dir.Text = "&Submit:";
            Dir.UseVisualStyleBackColor = false;
            Dir.Click += Dir_Click;
            // 
            // Tirtir
            // 
            Tirtir.BackColor = Color.FromArgb(255, 192, 255);
            Tirtir.Location = new Point(150, 449);
            Tirtir.Name = "Tirtir";
            Tirtir.Size = new Size(112, 34);
            Tirtir.TabIndex = 4;
            Tirtir.Text = "&Clear:";
            Tirtir.UseVisualStyleBackColor = false;
            Tirtir.Click += Tirtir_Click;
            // 
            // Extra
            // 
            Extra.AutoSize = true;
            Extra.BackColor = Color.White;
            Extra.Location = new Point(228, 306);
            Extra.Name = "Extra";
            Extra.Size = new Size(158, 29);
            Extra.TabIndex = 3;
            Extra.Text = "&Extra-curricular:";
            Extra.UseVisualStyleBackColor = false;
            // 
            // Courses
            // 
            Courses.FormattingEnabled = true;
            Courses.ItemHeight = 25;
            Courses.Items.AddRange(new object[] { "Java", "C#", "HTML&CSS3", "React" });
            Courses.Location = new Point(28, 306);
            Courses.Name = "Courses";
            Courses.Size = new Size(180, 129);
            Courses.TabIndex = 2;
            // 
            // Result
            // 
            Result.BackColor = Color.FromArgb(255, 192, 192);
            Result.Location = new Point(28, 490);
            Result.Name = "Result";
            Result.Size = new Size(358, 165);
            Result.TabIndex = 0;
            // 
            // groupBox2
            // 
            groupBox2.BackColor = Color.FromArgb(255, 128, 255);
            groupBox2.Controls.Add(Dumar);
            groupBox2.Controls.Add(Nin);
            groupBox2.Controls.Add(Sage);
            groupBox2.Controls.Add(Sid);
            groupBox2.Controls.Add(Sname);
            groupBox2.Controls.Add(ST_Sanadka);
            groupBox2.Controls.Add(ID);
            groupBox2.Controls.Add(magaca);
            groupBox2.Location = new Point(28, 28);
            groupBox2.Name = "groupBox2";
            groupBox2.Size = new Size(374, 263);
            groupBox2.TabIndex = 0;
            groupBox2.TabStop = false;
            groupBox2.Text = "StudentInfo";
            // 
            // Nin
            // 
            Nin.AutoSize = true;
            Nin.BackColor = Color.White;
            Nin.Location = new Point(101, 199);
            Nin.Name = "Nin";
            Nin.Size = new Size(79, 29);
            Nin.TabIndex = 1;
            Nin.TabStop = true;
            Nin.Text = "&Male:";
            Nin.UseVisualStyleBackColor = false;
            // 
            // Sage
            // 
            Sage.Location = new Point(169, 143);
            Sage.Name = "Sage";
            Sage.Size = new Size(150, 31);
            Sage.TabIndex = 1;
            // 
            // Sid
            // 
            Sid.Location = new Point(169, 99);
            Sid.Name = "Sid";
            Sid.Size = new Size(150, 31);
            Sid.TabIndex = 1;
            // 
            // Sname
            // 
            Sname.Location = new Point(169, 45);
            Sname.Name = "Sname";
            Sname.Size = new Size(150, 31);
            Sname.TabIndex = 1;
            // 
            // ST_Sanadka
            // 
            ST_Sanadka.BackColor = Color.White;
            ST_Sanadka.Location = new Point(6, 143);
            ST_Sanadka.Name = "ST_Sanadka";
            ST_Sanadka.Size = new Size(134, 31);
            ST_Sanadka.TabIndex = 0;
            ST_Sanadka.Text = "&Student Age:";
            ST_Sanadka.TextAlign = ContentAlignment.TopRight;
            // 
            // ID
            // 
            ID.BackColor = Color.White;
            ID.Location = new Point(6, 99);
            ID.Name = "ID";
            ID.Size = new Size(134, 31);
            ID.TabIndex = 0;
            ID.Text = "&Student ID:";
            ID.TextAlign = ContentAlignment.TopRight;
            // 
            // magaca
            // 
            magaca.BackColor = Color.White;
            magaca.BorderStyle = BorderStyle.Fixed3D;
            magaca.Location = new Point(6, 45);
            magaca.Name = "magaca";
            magaca.Size = new Size(134, 28);
            magaca.TabIndex = 0;
            magaca.Text = "&Student Name:";
            magaca.TextAlign = ContentAlignment.TopRight;
            // 
            // Dumar
            // 
            Dumar.AutoSize = true;
            Dumar.BackColor = Color.White;
            Dumar.Location = new Point(200, 199);
            Dumar.Name = "Dumar";
            Dumar.Size = new Size(97, 29);
            Dumar.TabIndex = 1;
            Dumar.TabStop = true;
            Dumar.Text = "&Female:";
            Dumar.UseVisualStyleBackColor = false;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1001, 796);
            Controls.Add(groupBox1);
            Name = "Form1";
            Text = "Form1";
            groupBox1.ResumeLayout(false);
            groupBox1.PerformLayout();
            groupBox2.ResumeLayout(false);
            groupBox2.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        private GroupBox groupBox1;
        private GroupBox groupBox2;
        private Label magaca;
        private RadioButton Nin;
        private ListBox Courses;
        private CheckBox Extra;
        private Button Kawadabax;
        private TextBox Sage;
        private TextBox Sid;
        private TextBox Sname;
        private Label ST_Sanadka;
        private Label ID;
        private Button Dir;
        private Button Tirtir;
        private Label Result;
        private RadioButton Dumar;
    }
}
