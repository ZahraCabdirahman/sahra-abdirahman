using System;
using System.Xml.Linq;

namespace Zahra_Abdiraxmaan_Ahmed
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Dir_Click(object sender, EventArgs e)
        {
            String Name = Sname.Text;
            String gender = "";
            double Num,Age, ID;

            if (double.TryParse(Sname.Text, out Num))
            {
                MessageBox.Show("Invalid Name!", "Error...", MessageBoxButtons.OK, MessageBoxIcon.Error);
                Sname.Clear();
                Sname.Focus();
                return;
            }
            else
            {
                Name = Sname.Text;
            }

            if (!double.TryParse(Sid.Text, out ID))
            {
                MessageBox.Show("Invalid ID", "Error...", MessageBoxButtons.OK, MessageBoxIcon.Error);
                Sid.Clear();
                Sid.Focus();
                return;
            }

            if (!double.TryParse(Sage.Text, out Age))
            {
                MessageBox.Show("Invalid Age", "Error...", MessageBoxButtons.OK, MessageBoxIcon.Error);
                Sage.Clear();
                Sage.Focus();
                return;
            }

            if (Age < 18)
            {
                MessageBox.Show("You can't enrol this course becouse you are young", "Error...", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            else if (Age > 30)
            {
                MessageBox.Show("You can't enrol this course becouse you are old", "Error...", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }


            if (Dumar.Checked == true)
            {
                gender = "Female";
            }
            else if (Nin.Checked == true)
            {
                gender = "Male";
            }
            else
            {
                MessageBox.Show("You must choose Male or Female", "Error...", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }


            string Cource = "";



            string extra_click = "";

            if (Courses.SelectedIndex != -1)
            {
                Cource = Courses.SelectedItem.ToString();

                extra_click = "Yes";

                switch (Cource)
                {
                    case "C#":
                        Result.Text = "Your Name is:" + Name + "\n" + "Your Age is:" + Age.ToString() + "\n" +
                             "Your ID is: " + ID.ToString() + "\n" + "Your gender is: " + gender + "\n" + "Course is : " + Cource;

                        break;
                    case "Java":
                        Result.Text = "Your Name is:" + Name + "\n" + "Your Age is:" + Age.ToString() + "\n" +
                             "Your ID is: " + ID.ToString() + "\n" + "Your gender is: " + gender + "\n" + "Course is : " + Cource;
                        break;
                    case "HTML&CSS3":
                        Result.Text = "Your Name is:" + Name + "\n" + "Your Age is:" + Age.ToString() + "\n" +
                             "Your ID is: " + ID.ToString() + "\n" + "Your gender is: " + gender + "\n" + "Course is : " + Cource;

                        break;
                    case "React":
                        Result.Text = "Your Name is: " + Name + "\n" + "Your Age is: " + Age.ToString() + "\n" +
                            "Your ID is: " + ID.ToString() + "\n" + "Your gender is: " + gender + "\n" + "Course is: " + Cource;

                        break;



                }
            }
            else
            {
                MessageBox.Show("please choose at least one course.", "Error...", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            if (Extra.Checked)
            {
                extra_click = "yes";
                Result.Text = "Your Name is: " + Name + "\n" + "Your Age is: " + Age.ToString() + "\n" +
                           "Your ID is: " + ID.ToString() + "\n" + "Your gender is: " + gender + "\n" + "Course is: " + Cource + "\n" + "The Extra is:" + extra_click;
            }
            else
            {
                //no
            }
            Sname.Focus();
        }

        private void Tirtir_Click(object sender, EventArgs e)
        {
            Result.Text = "";
            Nin.Checked = false;
            Dumar.Checked = false;
            Sname.Text = "";
            Sid.Text = "";
            Sage.Text = "";
            Courses.ClearSelected();
            Extra.Checked = false;
        }

        private void Kawadabax_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}



